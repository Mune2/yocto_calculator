int subtract(int a, int b) 
{
    return a - b;

}

